//-------- DEEPL TRANSLATOR ------------------------------

const apiKey = "d52fdef4-1942-43f2-9dca-37990b670e51:fx";
const baseURL = "https://api-free.deepl.com/v2/translate";

function detectAndSetBrowserLanguage() {
  const userLanguage = navigator.language || navigator.userLanguage;
  const targetLangSelect = document.getElementById("target-lang");
  const supportedLanguages = [
    "BG",
    "CS",
    "DA",
    "DE",
    "EL",
    "EN",
    "ES",
    "ET",
    "FI",
    "FR",
    "HU",
    "ID",
    "IT",
    "JA",
    "KO",
    "LT",
    "LV",
    "NB",
    "NL",
    "PL",
    "PT",
    "RO",
    "RU",
    "SK",
    "SL",
    "SV",
    "TR",
    "UK",
    "ZH",
  ];

  // Extract the two-letter language code from the browser language (e.g., "en", "es", etc.)
  const browserLangCode = userLanguage.substring(0, 2).toUpperCase();

  // Check if the browser language is supported in the translator
  if (supportedLanguages.includes(browserLangCode)) {
    targetLangSelect.value = browserLangCode;
  } else {
    // If the browser language is not in the supported languages, fall back to English
    targetLangSelect.value = "EN";
  }
}

// Call the function on page load to detect and set the browser language
document.addEventListener(
  "DOMContentLoaded",
  detectAndSetBrowserLanguage
);
// ---------------- GOOGLE TRANSLATOR --------------------

const inputLanguageDropdown = document.querySelector("#input-language");
const outputLanguageDropdown = document.querySelector("#output-language");
const inputTextElem = document.querySelector("#input-text");
const outputTextElem = document.querySelector("#output-text");

function populateDropdown(dropdown, options) {
  dropdown.innerHTML = ""; // Clear previous options
  options.forEach((option, index) => {
    const optionElem = document.createElement("option");
    if (index === 0 && option.code === "auto") {
      optionElem.textContent = "Auto Detect";
    } else {
      optionElem.textContent = option.name + " (" + option.native + ")";
    }
    optionElem.value = option.code;
    dropdown.appendChild(optionElem);
  });
}


populateDropdown(inputLanguageDropdown, languages);
populateDropdown(outputLanguageDropdown, languages);

// Get the browser's preferred language
const preferredLanguage = navigator.language.split("-")[0];

// Check if the preferred language is supported; if not, use EN as default
const defaultTargetLanguage = languages.some((lang) => lang.code === preferredLanguage)
  ? preferredLanguage
  : "en";

outputLanguageDropdown.value = defaultTargetLanguage;
translate();



inputLanguageDropdown.addEventListener("change", translate);
outputLanguageDropdown.addEventListener("change", translate);
inputTextElem.addEventListener("input", translate);

const swapBtn = document.querySelector(".swap-position");

swapBtn.addEventListener("click", (e) => {
  const tempInputLanguageValue = inputLanguageDropdown.value;
  inputLanguageDropdown.value = outputLanguageDropdown.value;
  outputLanguageDropdown.value = tempInputLanguageValue;
  translate();
});

function translate() {
  const inputText = inputTextElem.value;
  const inputLanguage = inputLanguageDropdown.value;
  const outputLanguage = outputLanguageDropdown.value;
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${inputLanguage}&tl=${outputLanguage}&dt=t&q=${encodeURI(
    inputText
  )}`;
  fetch(url)
    .then((response) => response.json())
    .then((json) => {
      console.log(json);
      outputTextElem.value = json[0].map((item) => item[0]).join("");
    })
    .catch((error) => {
      console.log(error);
    });
}

//-------- DETECT ON GOOGLE --------------------------------

  // Add the content from languages.js to the target dropdown menu
  const targetLangSelect = document.getElementById("target-langGoogle");
  languages.forEach((language) => {
    const option = document.createElement("option");
    option.value = language.code;
    option.text = language.name;
    targetLangSelect.appendChild(option);
  });

  function detectAndSetBrowserLanguageGoogle() {
    const userLanguage = navigator.language || navigator.userLanguage;

    // Extract the two-letter language code from the browser language (e.g., "en", "es", etc.)
    const browserLangCode = userLanguage.substring(0, 2).toLowerCase();

    // Check if the browser language is supported in the translator
    const supportedLanguages = languages.map((language) => language.code.toLowerCase());
    if (supportedLanguages.includes(browserLangCode)) {
      targetLangSelect.value = browserLangCode;
    } else {
      // If the browser language is not in the supported languages, fall back to "auto" (Auto Detect)
      targetLangSelect.value = "en";
    }
  }

  // Call the detectAndSetBrowserLanguage function on page load
  document.addEventListener("DOMContentLoaded", detectAndSetBrowserLanguageGoogle);



//--------- REVERSE BUTTON ------------------------------------

function reverseLanguages() {
  const sourceLang = document.getElementById("source-lang").value;
  const targetLang = document.getElementById("target-lang").value;

  // Get the values of the text areas before swapping languages
  const sourceText = document.getElementById("source-text").value;
  const translatedText = document.getElementById("translated-text").value;

  const textContainer = document.querySelector(".text");

  // Apply fade-out class to the text container
  textContainer.classList.add("fade-out");

  // Swap the values with a delay to allow the fade-out transition to happen
  setTimeout(() => {
    document.getElementById("source-lang").value = targetLang;
    document.getElementById("target-lang").value = sourceLang;
    document.getElementById("source-text").value = translatedText;
    document.getElementById("translated-text").value = sourceText;

    // Remove fade-out class after a delay to trigger the fade-in transition
    setTimeout(() => {
      textContainer.classList.remove("fade-out");
    }, 100);
  }, 100);
}

function reverseLanguagesGoogle() {
  const inputLanguage = document.getElementById("input-language").value;
  const outputLanguage = document.getElementById("output-language").value;

  // Get the values of the text areas before swapping languages
  const inputText = document.getElementById("input-text").value;
  const outputText = document.getElementById("output-text").value;

  const textContainer = document.querySelector(".text");

  // Apply fade-out class to the text container
  textContainer.classList.add("fade-out");

  // Swap the values with a delay to allow the fade-out transition to happen
  setTimeout(() => {
    document.getElementById("input-language").value = outputLanguage;
    document.getElementById("output-language").value = inputLanguage;
    document.getElementById("input-text").value = outputText;
    document.getElementById("output-text").value = inputText;

    // Remove fade-out class after a delay to trigger the fade-in transition
    setTimeout(() => {
      textContainer.classList.remove("fade-out");
    }, 100);
  }, 100);
}


//----------- COPY TRANSLATION -------------------------------

function copyTranslatedText() {
  // Get the text from the first text area
  const translatedText = document.getElementById("translated-text").value;

  // Get the text from the second text area
  const translatedTextGoogle = document.getElementById("output-text").value;

  // Combine the text from both text areas with a separator (e.g., newline)
  const combinedText = translatedText + translatedTextGoogle;

  // Create a temporary textarea element to copy the text to the clipboard
  const tempTextarea = document.createElement("textarea");
  tempTextarea.style.position = "fixed";
  tempTextarea.style.opacity = 0;
  tempTextarea.value = combinedText;
  document.body.appendChild(tempTextarea);

  // Copy the text from the temporary textarea to the clipboard
  tempTextarea.select();
  document.execCommand("copy");

  // Clean up: remove the temporary textarea element
  document.body.removeChild(tempTextarea);

  // Show the notification message
  const notification = document.getElementById("notification");
  notification.textContent = "Text copied to clipboard!";
  notification.style.display = "block";

  // Show the notification message for the second textarea
  const notificationGoogle = document.getElementById("notificationGoogle");
  notificationGoogle.textContent = "Text copied to clipboard!";
  notificationGoogle.style.display = "block";

  // Hide the notification after 3 seconds (adjust the duration as needed)
  setTimeout(() => {
    notification.style.display = "none";
    notificationGoogle.style.display = "none";
  }, 3000);
}


  
  
// ---------- DOWNLOAD TEXT -----------------------------------  

function downloadTextAsFile() {
  // Get the text from the first text area
  const translatedText = document.getElementById("translated-text").value;

  // Get the text from the second text area
  const translatedTextGoogle = document.getElementById("output-text").value;

  // Combine the text from both text areas with a separator (e.g., newline)
  const combinedText = translatedText + translatedTextGoogle;

  // Create a Blob containing the text data
  const blob = new Blob([combinedText], { type: "text/plain" });

  // Create a temporary anchor element
  const tempAnchor = document.createElement("a");
  tempAnchor.href = URL.createObjectURL(blob);

  // Set the filename for the downloaded file (you can customize this)
  tempAnchor.download = "translated_text.txt";

  // Simulate a click on the anchor to trigger the download
  tempAnchor.click();

  // Clean up: revoke the object URL to release resources
  URL.revokeObjectURL(tempAnchor.href);
}

//---------- TRANSLATOR DEEP L --------------------------------
  
async function translateText() {
  const sourceText = document.getElementById("source-text").value;
  const sourceLang = document.getElementById("source-lang").value;
  const targetLang = document.getElementById("target-lang").value;

  const params = {
    auth_key: apiKey,
    text: sourceText,
    source_lang: sourceLang,
    target_lang: targetLang,
  };

  try {
    const response = await fetch(baseURL, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams(params),
    });

    if (!response.ok) {
      throw new Error("Translation request failed.");
    }

    const data = await response.json();
    const translatedText = data.translations[0].text;

    document.getElementById("translated-text").value = translatedText;
  } catch (error) {
    console.error("Error translating text:", error.message);
  }
}

//---------- RESET -------------------------------

function resetTranslation() {
  const characterCounter = document.getElementById("character-counter");
  const characterCounterGoogle = document.getElementById("character-counter-google");

  // Set the source language to "EN"
  document.getElementById("source-lang").value = "EN";
  detectAndSetBrowserLanguage()
  document.getElementById("input-language").value = "auto";
  document.getElementById("output-language").value = defaultTargetLanguage;

  // Clear the source and translated text areas
  document.getElementById("source-text").value = "";
  document.getElementById("translated-text").value = "";
  document.getElementById("input-text").value = "";
  document.getElementById("output-text").value = "";

  // Update the character counter to 0
  characterCounter.textContent = "0/5000 characters";
  characterCounterGoogle.textContent = "0/5000 characters";

}
//---------- COUNTER -------------------------------

  // Function to update the character counter
  function updateCharacterCounter() {
    const textarea = document.getElementById("source-text");
    const maxLength = 5000;
    const currentLength = textarea.value.length;
    const characterCounter = document.getElementById("character-counter");
    characterCounter.textContent =
      currentLength + "/" + maxLength + " characters";
  }

  // Trigger the updateCharacterCounter() function on input event
  document
    .getElementById("source-text")
    .addEventListener("input", updateCharacterCounter);


//-----

// Function to update the character counter
function updateCharacterCounterGoogle() {
  const textarea = document.getElementById("input-text");
  const maxLength = 5000;
  const currentLength = textarea.value.length;
  const characterCounter = document.getElementById("character-counter-google");
  characterCounter.textContent =
    currentLength + "/" + maxLength + " characters";
}

// Trigger the updateCharacterCounter() function on input event
document
  .getElementById("input-text")
  .addEventListener("input", updateCharacterCounterGoogle);

// ------------- TOGGLE --------------------------

function toggleHelpFromDeepL() {
  const deepLtranslator = document.getElementById('deepLtranslator');
  const helpdialog = document.getElementById('helpDialog');

  deepLtranslator.classList.add('fade-out');
  helpdialog.classList.add('fade-in');

  setTimeout(() => {
    deepLtranslator.style.display = 'none';
    helpdialog.style.display = 'block';

    // Remove fade classes after transition is complete
    deepLtranslator.classList.remove('fade-out');
    helpdialog.classList.remove('fade-in');
  }, 300); // 500ms is the duration of the transition
}

function toggleBackToDeepL() {
  const deepLtranslator = document.getElementById('deepLtranslator');
  const helpdialog = document.getElementById('helpDialog');

  helpdialog.classList.add('fade-out');
  deepLtranslator.classList.add('fade-in');

  setTimeout(() => {
    helpdialog.style.display = 'none';
    deepLtranslator.style.display = 'block';

    // Remove fade classes after transition is complete
    helpdialog.classList.remove('fade-out');
    deepLtranslator.classList.remove('fade-in');
  }, 300); // 500ms is the duration of the transition
}

function toggleGoogleTranslator() {
  const helpdialog = document.getElementById('helpDialog');
  const googleTranslator = document.getElementById('GoogleTranslator');

  helpdialog.classList.add('fade-out');
  googleTranslator.classList.add('fade-in');

  setTimeout(() => {
    helpdialog.style.display = 'none';
    googleTranslator.style.display = 'block';

    // Remove fade classes after transition is complete
    helpdialog.classList.remove('fade-out');
    googleTranslator.classList.remove('fade-in');
  }, 300); // 500ms is the duration of the transition
}

function toggleBackToDeepLFromGoogle() {
  const googleTranslator = document.getElementById('GoogleTranslator');
  const deepLtranslator = document.getElementById('deepLtranslator');

  googleTranslator.classList.add('fade-out');
  deepLtranslator.classList.add('fade-in');

  setTimeout(() => {
    googleTranslator.style.display = 'none';
    deepLtranslator.style.display = 'block';

    // Remove fade classes after transition is complete
    googleTranslator.classList.remove('fade-out');
    deepLtranslator.classList.remove('fade-in');
  }, 300); // 500ms is the duration of the transition
}